package com.example.oasisunitconverter;

import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity {

    Spinner categorySpinner, sourceSpinner, targetSpinner;
    EditText valueInput;
    Button convertButton;
    TextView resultText;

    String[] categories = {
            "Length", "Weight", "Volume", "Speed", "Temperature"
    };

    String[][] units = {
            {"Metre", "Kilometre", "Centimetre", "Millimetre", "Inch", "Foot"},
            {"Kilogram", "Gram", "Milligram", "Pound"},
            {"Litre", "Millilitre", "US Gallon"},
            {"Metres/second", "Kilometres/hour", "Miles/hour"},
            {"Celsius", "Fahrenheit", "Kelvin"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        categorySpinner = findViewById(R.id.categorySpinner);
        sourceSpinner = findViewById(R.id.sourceSpinner);
        targetSpinner = findViewById(R.id.targetSpinner);
        valueInput = findViewById(R.id.valueInput);
        convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);

        ArrayAdapter<String> categoryAdapter =
                createDarkAdapter(categories);
        categorySpinner.setAdapter(categoryAdapter);

        categorySpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {
                        updateUnits(position);
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent) {
                    }
                });

        convertButton.setOnClickListener(v -> convert());
    }

    private ArrayAdapter<String> createDarkAdapter(String[] items) {
        return new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                items) {

            @Override
            public View getView(
                    int position,
                    View convertView,
                    ViewGroup parent) {

                TextView text = (TextView) super.getView(
                        position, convertView, parent);

                text.setTextColor(Color.WHITE);
                text.setTextSize(16);
                text.setPadding(12, 8, 12, 8);
                return text;
            }

            @Override
            public View getDropDownView(
                    int position,
                    View convertView,
                    ViewGroup parent) {

                TextView text = (TextView) super.getDropDownView(
                        position, convertView, parent);

                text.setTextColor(Color.WHITE);
                text.setTextSize(16);
                text.setPadding(20, 16, 20, 16);
                text.setBackgroundColor(Color.rgb(21, 29, 50));

                return text;
            }
        };
    }

    private void updateUnits(int index) {
        ArrayAdapter<String> adapter =
                createDarkAdapter(units[index]);

        sourceSpinner.setAdapter(adapter);
        targetSpinner.setAdapter(adapter);

        if (units[index].length > 1) {
            targetSpinner.setSelection(1);
        }

        resultText.setText("Your result will appear here");
        valueInput.setError(null);
    }

    private void convert() {
        String input = valueInput.getText().toString().trim();

        if (input.isEmpty()) {
            valueInput.setError("Please enter a value");
            valueInput.requestFocus();
            Toast.makeText(
                    this,
                    "Enter a number first",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        try {
            double value = Double.parseDouble(input);

            if (!Double.isFinite(value)) {
                throw new NumberFormatException();
            }

            String category =
                    categorySpinner.getSelectedItem().toString();
            String from =
                    sourceSpinner.getSelectedItem().toString();
            String to =
                    targetSpinner.getSelectedItem().toString();

            if (category.equals("Temperature")
                    && from.equals("Kelvin") && value < 0) {
                valueInput.setError(
                        "Kelvin cannot be below absolute zero");
                return;
            }

            if (category.equals("Temperature")
                    && from.equals("Celsius") && value < -273.15) {
                valueInput.setError(
                        "Below absolute zero is not valid");
                return;
            }

            if (category.equals("Temperature")
                    && from.equals("Fahrenheit") && value < -459.67) {
                valueInput.setError(
                        "Below absolute zero is not valid");
                return;
            }

            double result;

            if (category.equals("Temperature")) {
                result = convertTemperature(value, from, to);
            } else {
                result = value * factor(category, from)
                        / factor(category, to);
            }

            if (!Double.isFinite(result)) {
                throw new NumberFormatException();
            }

            String formatted = BigDecimal.valueOf(result)
                    .setScale(6, java.math.RoundingMode.HALF_UP)
                    .stripTrailingZeros()
                    .toPlainString();

            resultText.setText(
                    input + " " + from + "\n= " + formatted + " " + to
            );

            valueInput.setError(null);

        } catch (NumberFormatException e) {
            valueInput.setError("Please enter a valid number");
            Toast.makeText(
                    this,
                    "Please enter a valid number",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private double factor(String category, String unit) {
        switch (category) {
            case "Length":
                switch (unit) {
                    case "Metre": return 1.0;
                    case "Kilometre": return 1000.0;
                    case "Centimetre": return 0.01;
                    case "Millimetre": return 0.001;
                    case "Inch": return 0.0254;
                    case "Foot": return 0.3048;
                }
                break;

            case "Weight":
                switch (unit) {
                    case "Kilogram": return 1.0;
                    case "Gram": return 0.001;
                    case "Milligram": return 0.000001;
                    case "Pound": return 0.45359237;
                }
                break;

            case "Volume":
                switch (unit) {
                    case "Litre": return 1.0;
                    case "Millilitre": return 0.001;
                    case "US Gallon": return 3.785411784;
                }
                break;

            case "Speed":
                switch (unit) {
                    case "Metres/second": return 1.0;
                    case "Kilometres/hour": return 1.0 / 3.6;
                    case "Miles/hour": return 0.44704;
                }
                break;
        }

        return 1.0;
    }

    private double convertTemperature(
            double value, String from, String to) {

        double celsius;

        switch (from) {
            case "Fahrenheit":
                celsius = (value - 32) * 5.0 / 9.0;
                break;

            case "Kelvin":
                celsius = value - 273.15;
                break;

            default:
                celsius = value;
        }

        switch (to) {
            case "Fahrenheit":
                return celsius * 9.0 / 5.0 + 32;

            case "Kelvin":
                return celsius + 273.15;

            default:
                return celsius;
        }
    }
}
